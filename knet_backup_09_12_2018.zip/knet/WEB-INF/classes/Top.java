//This servlet is used to serve the top banner, because reasons:
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class Top extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Open writer:
		BufferedWriter out=new BufferedWriter(res.getWriter());
		//Open page:
		File home=new File("/home/adrian/apache-tomcat/webapps/knet/html/top.html");
		BufferedReader fin=new BufferedReader(new FileReader(home));
		String temp=new String();
		//Write page:
		while((temp=fin.readLine())!=null) out.write(temp);
		//Close and finish:
		fin.close();
		out.close();
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
