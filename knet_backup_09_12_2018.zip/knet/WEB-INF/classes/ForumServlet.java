//This servlet is used to serve forum pages and sign in/sign up forms:
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.crypto.*;
import java.sql.*;

public class ForumServlet extends HttpServlet {
	//BufferedWriter to be shared by all private methods:
	private BufferedWriter out=null;
	
	//Directly check if user's session-id is valid (Should connect to SQL server):
	private boolean isValidSession(String sessionid) {
		try {
			//Connect to SQL server:
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select sessionid from users where sessionid like " + sessionid);
			//Check if user already exists, return true if so:
			if(rs.next()) return true;
		} catch(SQLException s) {
			return false;
		}
		//Otherwise...
		return false;
	}
	
	//Display a thread, using the thread id, If threadid==0, display the home page:
	private void showThread(String threadid) throws IOException {
		this.out.write("<html><body>heyyyyy</body></html>");
		this.out.flush();
		//TODO
	}
	
	//Create a new thread:
	private void createThread(String title, String op) {
		//TODO
	}
	
	//Add a reply to the specified thread:
	private void replyThread(String threadid, String sessionid, String reply) {
		//TODO
	}
	
	//Display login/registration form, with or without error message:
	private void showLogin(String error) {
		//TODO
	}
	
	/*
	User verification/Thread show process /forum?threadid=THREAD:
	1. Get session cookie.
	2. If session cookie does not exist, display the form which redirects to /user?action=login|register|logout. The UserServlet will handle the above actions.
	3. If sessionid exists, directly send over forum home page with /forum?threadid=0
	
	Thread creation process /forum?action=create&title=TITLE:
	1. Get session cookie, etc.
	2. The top of the home page will have a title box and a "Create" button, which will trigger createThread()
	
	Thread reply process /forum?action=reply&threadid=THREAD&content=CONTENT:
	1. Get session cookie, etc.
	2. Just under the OP, a reply box and a "Reply" button will be available, which will trigger replyThread()
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Open output stream:
		this.out=new BufferedWriter(res.getWriter());
		
		//Get session cookie:
		Cookie[] c=req.getCookies();
		//If cookie is valid...
		for(Cookie c1: c)
			if(c1.getName().equals("session-id")) {
				if(isValidSession(c1.getValue()))
					showThread("0");
				else {
					//Read login form:
					File home=new File(getServletContext().getRealPath("/html/login.html"));
					BufferedReader fin=new BufferedReader(new FileReader(home));
					String temp=new String();
					while((temp=fin.readLine())!=null) out.write(temp);
					out.close();
				}
				break;
			}
		//TODO
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
