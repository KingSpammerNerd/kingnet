//This servlet handles the following user actions: login, register, logout.
/*
How this should work:
1. The FormServlet checks for a session-id cookie.
2. If it isn't there, it will display a login/registration form.
3. The form sends a redirect to this servlet, and in turn, this will perform the requested action, send over/delete the session cookie and redirect back to the ForumServlet, which should recognize the session cookie and log the user in.
*/

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;
import java.security.*;
import java.util.Base64;

public class UserServlet extends HttpServlet {
	//Create an account. Request syntax /user?action=create&username=USER&password=PASSWORD :
	private boolean createAccount(String username, String password) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select username from users where username like " + username);
		
		//Check if user already exists, return false if so:
		if(rs.next()) return false;
		
		//Create account:
		//Hash the password and encode it to Base64:
		MessageDigest sha256=MessageDigest.getInstance("SHA-256");
		byte[] passhash=sha256.digest(password.getBytes());
		String ph64=Base64.getEncoder().encodeToString(passhash);
		//Insert values into users table:
		st.executeUpdate("insert into users values(\'" + username + "\',\'" + ph64 + "\',\'none\')");
		
		//Return success:
		return true;
	}
	
	//Login to account, using login form and return session-id (sessionid) /user?action=login&username=USER&password=PASSWORD :
	private String login(String username, String password) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select username,passhash from users where username like \'" + username + "\'");
		
		String sessionid=new String("0");
		//Check if user exists:
		if(rs.next()) return sessionid;
		
		//Check account:
		//Hash the password and encode it to Base64:
		MessageDigest sha256=MessageDigest.getInstance("SHA-256");
		byte[] passhash=sha256.digest(password.getBytes());
		String ph64=Base64.getEncoder().encodeToString(passhash);
		//Check if passwords match:
		if(!rs.getString("passhash").equals(ph64)) return sessionid;
		else {
			//Generate sessionid:
			String sid=String.valueOf(System.currentTimeMillis());
			sid=sid.concat(username);
			byte[] dig=sha256.digest(sid.getBytes());
			//Set sessionid:
			sessionid=Base64.getEncoder().encodeToString(dig);
		}
		return sessionid;
	}
	
	//Logout /user?action=logout :
	private boolean logout(String sessionid) throws Exception {
		//Check if sessionid exists in DB:
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select sessionid from users where sessionid like \'" + sessionid + "\'");
		if(!rs.next()) return false;
		//Delete sessionid:
		st.executeUpdate("update users set sessionid=\'none\' where sessionid like \'" + sessionid + "\'");
		return true;
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		BufferedWriter out=new BufferedWriter(res.getWriter());
		//Process request:
		String action=req.getParameter("action");
		//Create new account:
		if(action.equals("create")) {
			boolean success=false;
			try {
				success=createAccount(req.getParameter("username"), req.getParameter("password"));
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error creating account: " + e.getMessage() + "</font></body></html>");
				return;
			}
			if(success)
			try {
				login(req.getParameter("username"), req.getParameter("password"));
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error logging in: " + e.getMessage() + "</font></body></html>");
				return;
			}
			else
				out.write("<html><body><font face=\"sans\">An unknown error occured. Sorry!</font></body></html>");
			out.close();
			return;
		}
		//Login:
		else if(action.equals("login")) {
			String sessionid=null;
			try {
				sessionid=login(req.getParameter("username"), req.getParameter("password"));
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error logging in: " + e.getMessage() + "</font></body></html>");
				return;
			}
			if(sessionid!=null) {
				res.addCookie(new Cookie("session-id", sessionid));
				res.sendRedirect("forum?threadid=0");
			}
			else {
				out.write("<html><body><font face=\"sans\">An unknown error occured. Sorry!</font></body></html>");
				out.flush();
			}
			out.close();
			return;
		}
		//Logout:
		else if(action.equals("logout")) {
			//Get cookies:
			Cookie[] c=req.getCookies();
			String sessionid=null;
			if(c!=null) for(Cookie c1: c) if(c1.getName().equals("session-id")) sessionid=c1.getValue();
			boolean success=false;
			try {
				if(sessionid==null) throw new Exception("Session cookie could not be retrieved.");
				success=logout(sessionid);
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error logging out: " + e.getMessage() + "</font></body></html>");
				out.flush();
				return;
			}
			if(success)
				res.sendRedirect("forum?threadid=0");
			else {
				out.write("<html><body><font face=\"sans\">An unknown error occured. Sorry!</font></body></html>");
				out.flush();
			}
			out.close();
			return;
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doPost(req, res);
	}
}
