//This servlet is used to serve forum pages and sign in/sign up forms:
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.crypto.*;
import java.sql.*;

public class ForumServlet extends HttpServlet {
	//BufferedWriter to be shared by all private methods:
	private BufferedWriter out=null;
	
	//Directly check if user's session-id is valid (Should connect to SQL server):
	private boolean isValidSession(String sessionid) {
		try {
			//Connect to SQL server:
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select sessionid from users where sessionid like " + sessionid);
			//Check if user already exists, return true if so:
			if(rs.next()) return true;
		} catch(SQLException s) {
			return false;
		}
		//Otherwise...
		return false;
	}
	
	//Display a thread, using the thread id, If threadid==0, display the home page:
	private void showThread(String threadid) throws IOException {
		//Start writing page:
		this.out.write("<html><body><font face=\"sans\">");
		//Write submission form:
		this.out.write("Create new thread:<br>");
		//Trigger the thread creation action:
		this.out.write("<form name=\"create\" align=\"left\" action=\"forum\"><input type=\"hidden\" method=\"post\" name=\"action\" value=\"create\">");
		this.out.write("Thread title: <input type=\"text\" name=\"title\">&nbsp;&nbsp;<input type=\"submit\">");
		this.out.flush();
		
		//Connect to SQL server:
		Statement st=null;
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
			st=con.createStatement();
		} catch(SQLException s1) {
			//Close page and exit:
			this.out.write("Error: " + s1.getMessage());
			this.out.write("</font></body></html>");
			this.out.flush();
			return;
		}
		//Display home page, if threadid is not specified, with a create button:
		if(threadid.equals("0")) {
			this.out.write("<h3>Home</h3>");
			this.out.write("<p align=\"right\"><a href=user?action=logout>Logout</a></p><br>");
			this.out.flush();
			try {		
				//Get details of all threads:
				ResultSet rs=st.executeQuery("select * from threads where threadid like " + threadid);
				//Print all thread details:
				while(rs.next()) {
					this.out.write("<a href=\"forum?threadid=" + rs.getString("threadid") + "\">" + rs.getString("title"));
					this.out.flush();
				}
			} catch(SQLException s2) {
				//Close page and exit:
				this.out.write("Error getting posts: " + s2.getMessage());
				this.out.write("</font></body></html>");
				this.out.flush();
				return;
			}
		}
		//Display thread, with a reply box and all:
		else {
			this.out.write("hol up, we're not done here yet!");
			this.out.write("</font></body></html>");
			return;
			//ResultSet rs=
			//TODO
		}
	}
	
	//Create a new thread. The title should be <title> by <username>:
	private void createThread(String title, String sessionid) {
		//TODO
	}
	
	//Add a reply to the specified thread:
	private void replyThread(String threadid, String sessionid, String reply) {
		//TODO
	}
	
	/*
	User verification/Thread show process /forum?threadid=THREAD:
	1. Get session cookie.
	2. If session cookie does not exist, display the form which redirects to /user?action=login|register|logout. The UserServlet will handle the above actions.
	3. If sessionid exists, directly send over forum home page with /forum?threadid=0
	
	Thread creation process /forum?action=create&title=TITLE:
	1. Get session cookie, etc.
	2. The top of the home page will have a title box and a "Create" button, which will trigger createThread()
	
	Thread reply process /forum?action=reply&threadid=THREAD&content=CONTENT:
	1. Get session cookie, etc.
	2. Just under the OP, a reply box and a "Reply" button will be available, which will trigger replyThread()
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Open output stream:
		this.out=new BufferedWriter(res.getWriter());
		
		//Get session cookie:
		Cookie[] c=req.getCookies();
		
		//Display thread:
		//If cookie is valid, set sessionValid=true and continue...
		String sessionid=null;
		if(c!=null)
			for(Cookie c1: c) if(c1.getName().equals("session-id")) {
				sessionid=c1.getValue();
				break;
			}
		else sessionid=new String("0");
		
		//...otherwise, send over the login/registration form:
		if(!isValidSession(sessionid)) {
			//Read login form:
			File home=new File(getServletContext().getRealPath("/html/login.html"));
			BufferedReader fin=new BufferedReader(new FileReader(home));
			String temp=new String();
			//Send login form:
			while((temp=fin.readLine())!=null) out.write(temp);
			out.close();
			return;
		}
		
		//Get "action" parameter:
		String action=req.getParameter("action");
		if(action==null) {
			//Check if client has specified a threadid:
			if(req.getParameter("threadid")==null) showThread("0");
			//Display requested thread:
			else showThread(req.getParameter("threadid"));
		}
		//Create a new thread:
		else if(action.equals("create")) {
			//TODO
		}
		//Reply to thread:
		else if(action.equals("reply")) {
			//TODO
		}
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
