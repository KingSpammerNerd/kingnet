//This servlet is used to serve the welcome page:

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class WelcomeServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Open welcome page:
		File wcm=new File(getServletContext().getRealPath("/html/welcome.html"));
		//Open output stream:
		BufferedWriter out=new BufferedWriter(res.getWriter());
		//Open file input stream:
		BufferedReader win=new BufferedReader(new FileReader(wcm));
		String w=new String();
		while((w=win.readLine())!=null) {
			out.write(w);
			out.flush();
		}
		//Close:
		out.close();
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
