//This servlet serves the FAQ page.

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class FAQServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Open writer:
		BufferedWriter out=new BufferedWriter(res.getWriter());
		//Open faqs.html:
		File f=new File(getServletContext().getRealPath("/html/faqs.html"));
		BufferedReader faq=new BufferedReader(new FileReader(f));
		//Write page:
		String ln=new String();
		while((ln=faq.readLine())!=null) {
			out.write(ln);
			out.flush();
		}
		out.close();
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
