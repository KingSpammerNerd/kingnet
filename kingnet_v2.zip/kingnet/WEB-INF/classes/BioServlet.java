//This servlet is used to serve user Bios, from the table knet.bios
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;

/*
The following methods are needed:
showUserList(sessionid): Sends over a list of all users, with links to their bios. PLUS a form for the current user to edit their own bio.
showBio(username): Sends the bio text for the specified username.
editBio(sessionid): Sends a form for the logged-in user to edit their bio.
changeBio(username, text): Changes the bio on the server-side.
*/

public class BioServlet extends HttpServlet {
	//Writer, shared by all methods:
	private BufferedWriter out=null;
	
	//Show list of all users:
	private void showUserList(String sessionid) throws Exception {
		//Start writing webpage:
		this.out.write("<html><body><font face=\"sans\">");
		this.out.write("<h4>The people of KingNET:</h4><br>");
		this.out.flush();
		
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		
		//Get logged-in user's username:
		PreparedStatement cun=con.prepareStatement("select username from users where sessionid like ?");
		cun.setString(1, sessionid);
		ResultSet unameRes=cun.executeQuery();
		String cuname=null;
		if(unameRes.next())
			cuname=unameRes.getString("username");
		else
			throw new Exception("Error verifying user credentials!");
		//Write current users's bio:
		PreparedStatement cu=con.prepareStatement("select bio from bios where username like ?");
		cu.setString(1, cuname);
		ResultSet cur=cu.executeQuery();
		String cub=null;
		if(cur.next()) {
			cub=cur.getString("bio");
			this.out.write("Your bio:&nbsp;" + cub + "<br>");
			this.out.write("<a href=\"bios?action=edit\">Edit</a>");
			this.out.write("<br><br>");
		}
		else
			this.out.write("Sorry, couldn't get your bio.");
		this.out.flush();
		
		//Select records from bios:
		PreparedStatement rec=con.prepareStatement("select username from bios");
		ResultSet bs=rec.executeQuery();
		//Write list of users:
		String un=null;
		while(bs.next()) {
			un=bs.getString("username");
			this.out.write("<a href=\"bios?action=show&username=" + un + "\">" + un + "</a><br>");
		}
		this.out.write("</font></body></html>");
		this.out.flush();
	}
	
	//Show bio for a given username:
	private void showBio(String username) throws Exception {
		//Start writing webpage:
		this.out.write("<html><body><font face=\"sans\">");
		this.out.write("<h3 align=\"center\">About " + username + ":</h3><br>");
		this.out.flush();
		
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		
		//Write selected users's bio:
		PreparedStatement cu=con.prepareStatement("select bio from bios where username like ?");
		cu.setString(1, username);
		ResultSet cur=cu.executeQuery();
		String cub=null;
		if(cur.next())
			cub=cur.getString("bio");
		else
			throw new Exception("Sorry, something's gone wrong.");
		this.out.write("<p align=\"center\"><font size=\"14\">" + cub + "</font></p>");
		this.out.write("</font></body></html>");
		this.out.flush();
	}
	
	//Edit current user's bio:
	private void editBio(String sessionid) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		//Get username from sessionid:
		PreparedStatement gun=con.prepareStatement("select username from users where sessionid like ?");
		gun.setString(1, sessionid);
		ResultSet gunr=gun.executeQuery();
		String username=null;
		if(gunr.next())
			username=gunr.getString("username");
		else
			throw new Exception("Invalid session, please login and try again.");
		//Get current bio:
		PreparedStatement gcb=con.prepareStatement("select bio from bios where username=?");
		gcb.setString(1, username);
		ResultSet gcbr=gcb.executeQuery();
		String cb=null;
		if(gcbr.next())
			cb=gcbr.getString("bio");
		else
			throw new Exception("Sorry, an error occured.");
		
		//Write form:
		this.out.write("<html><body><font face=\"sans\">");
		this.out.write("<h4>Editing your bio (max 300 chars):</h4><br>");
		this.out.write("<form action=\"bios\">");
		this.out.write("<input type=\"hidden\" name=\"action\" value=\"change\">");
		this.out.write("<input type=\"text\" name=\"text\" value=\"" + cb + "\" height=\"10\" width=40%>");
		this.out.flush();
		this.out.write("<br><input type=\"submit\" value=\"Save Changes\">");
		this.out.flush();
	}
	
	//Change the current user's bio, as provided in the edit form:
	private boolean changeBio(String sessionid, String text) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		//Get logged-in user's username:
		PreparedStatement cun=con.prepareStatement("select username from users where sessionid like ?");
		cun.setString(1, sessionid);
		ResultSet unameRes=cun.executeQuery();
		String cuname=null;
		if(unameRes.next())
			cuname=unameRes.getString("username");
		else
			throw new Exception("Error verifying user credentials!");
		
		//Set new bio:
		PreparedStatement chg=con.prepareStatement("update bios set bio=? where username like ?");
		chg.setString(1, text);
		chg.setString(2, cuname);
		if(chg.executeUpdate()!=1) return false;
		return true;
	}
	
	//Directly check if user's session-id is valid (Should connect to SQL server):
	private boolean isValidSession(String sessionid) {
		try {
			//Connect to SQL server:
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
			PreparedStatement chk=con.prepareStatement("select sessionid from users where sessionid like ?");
			chk.setString(1, sessionid);
			ResultSet rs=chk.executeQuery();
			//Check if user already exists, return true if so:
			if(rs.next()) return true;
		} catch(SQLException s) {
			return false;
		}
		//Otherwise...
		return false;
	}
	
	//Request handlers:
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		this.out=new BufferedWriter(res.getWriter());
		
		//Get session cookie:
		Cookie[] c=req.getCookies();
		
		//Display thread:
		//If cookie is valid, set sessionValid=true and continue...
		String sessionid=null;
		if(c!=null)
			for(Cookie c1: c) if(c1.getName().equals("session-id")) {
				sessionid=c1.getValue();
				break;
			}
		else sessionid=new String("0");
		
		//...otherwise, send over the login/registration form:
		if(!isValidSession(sessionid)) {
			//Read login form:
			File home=new File(getServletContext().getRealPath("/html/login.html"));
			BufferedReader fin=new BufferedReader(new FileReader(home));
			String temp=new String();
			//Send login form:
			while((temp=fin.readLine())!=null) out.write(temp);
			out.close();
			return;
		}
		
		//Get action parameter:
		String action=req.getParameter("action");
		//Perform action:
		if(action==null) {
			try {
				showUserList(sessionid);
				this.out.flush();
			} catch(Exception e) {
				this.out.write("Error: " + e.getMessage());
				this.out.flush();
			}
		}
		//Show bio for the selected user:
		else if(action.equals("show")) {
			String un=req.getParameter("username");
			try {
				showBio(un);
				this.out.flush();
			} catch(Exception e) {
				this.out.write("Error: " + e.getMessage());
				this.out.flush();
			}
		}
		//Show bio editor form:
		else if(action.equals("edit")) {
			try {
				editBio(sessionid);
			} catch(Exception e) {
				this.out.write("Error: " + e.getMessage());
				this.out.flush();
			}
		}
		//Change user's bio:
		else if(action.equals("change")) {
			String newBio=req.getParameter("text");
			try {
				changeBio(sessionid, newBio);
			} catch(Exception e) {
				this.out.write("Error: " + e.getMessage());
				this.out.flush();
				return;
			}
			//Redirect to bio page:
			res.sendRedirect("bios");
		}
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
