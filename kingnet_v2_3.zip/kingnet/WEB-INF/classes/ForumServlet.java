//This servlet is used to serve forum pages and sign in/sign up forms:
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import javax.crypto.*;
import java.sql.*;

public class ForumServlet extends HttpServlet {
	//BufferedWriter to be shared by all private methods:
	private BufferedWriter out=null;
	
	//Directly check if user's session-id is valid (Should connect to SQL server):
	private boolean isValidSession(String sessionid) {
		try {
			//Connect to SQL server:
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
			PreparedStatement chk=con.prepareStatement("select sessionid from users where sessionid like ?");
			chk.setString(1, sessionid);
			ResultSet rs=chk.executeQuery();
			//Check if user already exists, return true if so:
			if(rs.next()) return true;
		} catch(SQLException s) {
			return false;
		}
		//Otherwise...
		return false;
	}
	
	//Little helper function to display "title" part of a thread page:
	void writeTitle(String title) throws IOException {
		this.out.write("<table width=\"100%\">");
		this.out.write("<tr><td width=\"50%\" align=\"left\">");
		this.out.write("<h3>" + title + "</h3></td>");
		this.out.write("<td width=\"50%\" align=\"right\">");
		this.out.write("<a href=user?action=logout>Logout</a></td></tr></table><br>");
		this.out.flush();
	}
	
	//Display a thread, using the thread id, If threadid==0, display the home page:
	private void showThread(String threadid) throws Exception {
		//Start writing page:
		this.out.write("<html>");
		this.out.write("<head><style>a{color:#F2F2F2;text-decoration:none;} a:visited{color:#D8D8D8;text-decoration:none;} h3{color:#FFFFFF}</style></head>");
		this.out.write("<body><font face=\"sans\" color=\"#F2F2F2\">");
		//Write thread creation form:
		this.out.write("<b>Create new thread:</b><br>");
		this.out.write("<form name=\"create\" align=\"left\" method=\"post\" action=\"forum\"><input type=\"hidden\" name=\"action\" value=\"create\">");
		this.out.write("Thread title: <input type=\"text\" name=\"title\">&nbsp;&nbsp;<input type=\"submit\" value=\"Post\"><br></form>");
		this.out.flush();
		
		//Connect to SQL server:
		PreparedStatement home=null, td=null;
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
			home=con.prepareStatement("select threadid, title from threads");
			td=con.prepareStatement("select * from threads where threadid like ?");
		} catch(SQLException s1) {
			//Close page and exit:
			this.out.write("Error: " + s1.getMessage());
			this.out.write("</font></body></html>");
			this.out.flush();
			return;
		}
		
		//Display home page, if threadid is not specified, with a create button:
		if(threadid.equals("0")) {
			writeTitle("Home");
			try {		
				//Get details of all threads:
				ResultSet rs=home.executeQuery();
				//Print all thread details, from newest to oldest:
				if(rs.last()) do {
					this.out.write("<a href=\"forum?threadid=" + rs.getString("threadid") + "\">" + rs.getString("title") + "</a><br>");
					this.out.flush();
				} while(rs.previous());
			} catch(SQLException s2) {
				//Close page and exit:
				this.out.write("Error getting posts: " + s2.getMessage());
				this.out.write("</font></body></html>");
				this.out.flush();
				return;
			}
		}
		//Display thread, with a reply box and all:
		else {
			//Get thread details for specified threadid:
			td.setString(1, threadid);
			ResultSet tdr=td.executeQuery();
			//Write title and logout link:
			if(!tdr.next()) throw new Exception("Post not found!");
			writeTitle(tdr.getString("title"));
			//Write reply form:
			this.out.write("<form name=\"replyform\" method=\"post\" action=\"forum\">");
			this.out.write("<input type=\"hidden\" name=\"action\" value=\"reply\">");
			this.out.write("Reply:&nbsp;<input type=\"hidden\" name=\"threadid\" value=\"" + threadid + "\">");
			this.out.write("<input type=\"text\" name=\"content\">&nbsp;");
			this.out.write("<input type=\"submit\" value=\"Reply\"></form><br>");
			this.out.flush();
			
			//Write existing replies:
			//Open thread folder:
			File rf=new File(tdr.getString("posts_dir"));
			//Open each reply file and display its contents:
			File[] tf=rf.listFiles();
			for(int i=(tf.length)-1; i>=0; --i) {
				File temp=tf[i];
				//Create target byte array:
				byte[] t=new byte[(int)temp.length()];
				//Read contents:
				t=new FileInputStream(temp).readAllBytes();
				//Create string:
				String temps=new String(t, "UTF-8");
				//Write data to client:
				this.out.write(temps);
				this.out.write("<br>");
				this.out.flush();
			}
			
			this.out.write("</font></body></html>");
			this.out.flush();
			return;
		}
	}
	
	//Create a new thread. The title should be <username>: <title>:
	private String createThread(String title, String sessionid) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		PreparedStatement st=con.prepareStatement("select username from users where sessionid like ?");
		st.setString(1, sessionid);
		ResultSet rs=st.executeQuery();
		//Check if user exists:
		if(!rs.next()) throw new Exception("Ain't nobody by that name here!");
		
		//Get username:
		String uname=rs.getString("username");
		//Set threadid:
		String tid=String.valueOf(System.currentTimeMillis());
		tid=tid.concat(uname);
		//Set title:
		String tle=new String(uname);
		tle=tle.concat(": ");
		tle=tle.concat(title);
		//Check for illegal characters:
		if(tle.contains("<") || tle.contains(">") || tle.contains("{") || tle.contains("}")) throw new Exception("Illegal character(s) in title!");
		
		//Create thread folder:
		File tdir=new File(getServletContext().getRealPath("/threads/" + tid));
		tdir.mkdir();
		
		//Insert values into table threads:
		PreparedStatement nw=con.prepareStatement("insert into threads values(?,?,?)");
		nw.setString(1, tid);
		nw.setString(2, tle);
		nw.setString(3, tdir.toString());
		if(nw.executeUpdate()!=1) throw new Exception("Fatal error");
		
		//Return threadid:
		return tid;
	}
	
	//Add a reply to the specified thread:
	private void replyThread(String threadid, String sessionid, String reply) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		
		//Get username of poster:
		PreparedStatement unm=con.prepareStatement("select username from users where sessionid like ?");
		unm.setString(1, sessionid);
		String username=null;
		ResultSet un=unm.executeQuery();
		if(un.next()) username=un.getString("username");
		
		//Get replies directory of thread:
		PreparedStatement thd=con.prepareStatement("select posts_dir from threads where threadid like ?");
		thd.setString(1, threadid);
		String tdir=null;
		ResultSet d=thd.executeQuery();
		if(d.next()) tdir=d.getString("posts_dir");
		
		//Create reply ID:
		String rid=String.valueOf(System.currentTimeMillis());
		rid=rid.concat(username);
		//Set reply text:
		String tle=new String(username);
		tle=tle.concat(": ");
		tle=tle.concat(reply);
		//Check for illegal characters:
		if(tle.contains("<") || tle.contains(">") || tle.contains("{") || tle.contains("}")) throw new Exception("Illegal character(s) in reply!");
		//Create new reply file:
		tdir=tdir.concat("/" + rid);
		File ftdir=new File(tdir);
		//throw new Exception(tdr + "\n" + ftdir.toString());
		//ftdir.createNewFile();
		//Write reply to file:
		BufferedWriter fout=new BufferedWriter(new FileWriter(ftdir));
		fout.write(tle);
		fout.flush();
		fout.close();
	}
	
	/*
	User verification/Thread show process /forum?threadid=THREAD:
	1. Get session cookie.
	2. If session cookie does not exist, display the form which redirects to /user?action=login|register|logout. The UserServlet will handle the above actions.
	3. If sessionid exists, directly send over forum home page with /forum?threadid=0
	
	Thread creation process /forum?action=create&title=TITLE:
	1. Get session cookie, etc.
	2. The top of the home page will have a title box and a "Create" button, which will trigger createThread()
	
	Thread reply process /forum?action=reply&threadid=THREAD&content=CONTENT:
	1. Get session cookie, etc.
	2. Just under the OP, a reply box and a "Reply" button will be available, which will trigger replyThread()
	*/
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Open output stream:
		this.out=new BufferedWriter(res.getWriter());
		
		//Get session cookie:
		Cookie[] c=req.getCookies();
		
		//Display thread:
		//If cookie is valid, set sessionValid=true and continue...
		String sessionid=null;
		if(c!=null)
			for(Cookie c1: c) if(c1.getName().equals("session-id")) {
				sessionid=c1.getValue();
				break;
			}
		else sessionid=new String("0");
		
		//...otherwise, send over the login/registration form:
		if(!isValidSession(sessionid)) {
			//Read login form:
			File home=new File(getServletContext().getRealPath("/html/login.html"));
			BufferedReader fin=new BufferedReader(new FileReader(home));
			String temp=new String();
			//Send login form:
			while((temp=fin.readLine())!=null) out.write(temp);
			out.close();
			return;
		}
		
		//Get "action" parameter:
		String action=req.getParameter("action");
		if(action==null) {
			try {
				//Check if client has specified a threadid:
				if(req.getParameter("threadid")==null) showThread("0");
				//Display requested thread:
				else showThread(req.getParameter("threadid"));
			} catch(Exception e) {
				this.out.write("<html><body><font=\"sans\">Error: " + e.getMessage() + "</font></body></html>");
				this.out.flush();
			}
		}
		//Create a new thread:
		else if(action.equals("create")) {
			try {
				String title=req.getParameter("title");
				if(title.equals("")) throw new Exception("Empty title!");
				String threadid=createThread(title, sessionid);
				//Redirect user to newly created thread:
				res.sendRedirect("forum?threadid=" + threadid);
			} catch(Exception e1) {
				this.out.write("<html><body><font=\"sans\">Error: " + e1.getMessage() + "</font></body></html>");
				this.out.flush();
			}
		}
		//Reply to thread:
		else if(action.equals("reply")) {
			try {
				String threadid=req.getParameter("threadid");
				String reply=req.getParameter("content");
				if(reply.equals("")) throw new Exception("Empty reply!");
				//Post reply
				replyThread(threadid, sessionid, reply);
				//Redirect to same thread:
				res.sendRedirect("forum?threadid=" + threadid);
			} catch(Exception e1) {
				this.out.write("<html><body><font=\"sans\">Error: " + e1.getMessage() + "</font></body></html>");
				this.out.flush();
			}
		}
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
