//This servlet is used to serve user Bios, from the table knet.bios
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;

/*
The following methods are needed:
showUserList(sessionid): Sends over a list of all users, with links to their bios. PLUS a form for the current user to edit their own bio.
showBio(username): Sends the bio text for the specified username.
editBio(sessionid): Sends a form for the logged-in user to edit their bio.
changeBio(username, text): Changes the bio on the server-side.
*/

public class BioServlet extends HttpServlet {
	//Writer, shared by all methods:
	private BufferedWriter out=null;
	
	//Show list of all users:
	private void showUserList(String sessionid) throws Exception {
		//Start writing webpage:
		this.out.write("<html><body><font face=\"sans\">");
		this.out.write("<h4>The people of KingNET:</h4><br>");
		this.out.flush();
		
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		
		//Get logged-in user's username:
		PreparedStatement cun=con.prepareStatement("select username from users where sessionid like ?");
		cun.setString(1, sessionid);
		ResultSet unameRes=cun.executeQuery();
		String cuname=null;
		if(unameRes.next())
			cuname=unameRes.getString("username");
		else
			throw new Exception("Error verifying user credentials!");
		//Write current users's bio:
		PreparedStatement cu=con.prepareStatement("select bio from bios where username like ?");
		cu.setString(1, cuname);
		ResultSet cur=cu.executeQuery();
		String cub=null;
		if(cur.next()) {
			cub=cur.getString("bio");
			this.out.write("Your bio:&nbsp;" + cub + "<br>TODO: add edit funtion<br><br>");
		}
		else
			this.out.write("Sorry, couldn't get your bio.");
		this.out.flush();
		
		//Select records from bios:
		PreparedStatement rec=con.prepareStatement("select username from bios");
		ResultSet bs=rec.executeQuery();
		//Write list of users:
		String un=null;
		while(bs.next()) {
			un=bs.getString("username");
			this.out.write("<a href=\"bio?action=show&username=" + un + "\">" + un + "</a><br>");
		}
		this.out.write("</font></body></html>");
		this.out.flush();
	}
	
	//Show bio for a given username:
	private void showBio(String username) throws Exception {
		//Start writing webpage:
		this.out.write("<html><body><font face=\"sans\">");
		this.out.write("<h4 align=\"center\">About " + username + ":</h4><br>");
		this.out.flush();
		
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		
		//Write selected users's bio:
		PreparedStatement cu=con.prepareStatement("select bio from bios where username like ?");
		cu.setString(1, username);
		ResultSet cur=cu.executeQuery();
		String cub=null;
		if(cur.next())
			cub=cur.getString("bio");
		else
			throw new Exception("Sorry, something's gone wrong.");
		this.out.write("<p align=\"center\"><font size=\"18\">" + cub + "</font></p>");
		this.out.write("</font></body></html>");
		this.out.flush();
	}
	
	//Edit current user's bio:
	private void editBio(String sessionid) {
		//TODO
		
	}
	
	//Change the current user's bio, as provided in the edit form:
	private void changeBio(String username, String text) {
		//TODO
	}
	
	//Request handlers:
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		this.out=new BufferedWriter(res.getWriter());
		//Test code. Get the username getter from ForumServlet so that only logged-in users can see bios.
		/*try {
			showUserList("tester1");
		} catch(Exception e) { this.out.write("<html><body>" + e.getMessage() + "</body></html>"); this.out.flush(); }*/
		//TODO
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
