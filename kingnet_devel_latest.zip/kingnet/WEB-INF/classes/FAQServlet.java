//This servlet serves the FAQ page.

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class FAQServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		//Open writer:
		BufferedWriter out=new BufferedWriter(res.getWriter());
		//Write page:
		out.write("<html><body><font face=\"sans\">");
		out.write("<h2>FAQs</h2><br>");
		out.write("<ul>");
		out.write("<li><b>What is this?</b><br>This is supposed to be a 4chan/Twitter style shitposting heaven. As for what it *actually* is, I have no idea.</li>");
		out.write("<li><b>Why did you make it then?</b><br>This was a personal training exercise. Or at least, that's what I think it is.</li>");
		out.write("<li><b>So...what can I do here?</b><br>Forget that. Let's go over what you *can't* do here, including but not limited to: harassment, death threats, organized crime (you're not *that* stupid, are you?), porn (yes, I'm serious) and piracy (YES, I AM SERIOUS. If you have a problem with this, go back to 4chan.)</li>");
		out.write("<li><b>Okay, how does this work?</b><br>You create an account. You log in. Start shitposting. Log out. Rinse and repeat every few minutes.</li>");
		out.write("<li><b>Hey, this site looks like shit.</b><br>So do you, but I'm not calling you out on it.</li>");
		out.write("<li><b>HAPPY SHITPOSTING, LADIES AND GENTLEMEN</b></li>");
		out.write("</ul></font></body></html>");
		out.flush();
		out.close();
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);
	}
}
