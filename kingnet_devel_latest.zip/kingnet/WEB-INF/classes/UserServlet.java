//This servlet handles the following user actions: login, register, logout.
/*
How this should work:
1. The FormServlet checks for a session-id cookie.
2. If it isn't there, it will display a login/registration form.
3. The form sends a redirect to this servlet, and in turn, this will perform the requested action, send over/delete the session cookie and redirect back to the ForumServlet, which should recognize the session cookie and log the user in.
*/

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import java.io.*;
import java.security.*;
import java.util.Base64;

public class UserServlet extends HttpServlet {
	//Create an account. Request syntax /user?action=create&username=USER&password=PASSWORD :
	private boolean createAccount(String username, String password) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		//Check if user already exists, return false if so:
		PreparedStatement sel=con.prepareStatement("select username from users where username like ?");
		sel.setString(1, username);
		ResultSet rs=sel.executeQuery();
		if(rs.next()) return false;
		
		//Create account:
		//Hash the password and encode it to Base64:
		MessageDigest sha256=MessageDigest.getInstance("SHA-256");
		byte[] passhash=sha256.digest(password.getBytes());
		String ph64=Base64.getEncoder().encodeToString(passhash);
		//Insert values into users table:
		PreparedStatement ins=con.prepareStatement("insert into users values(?,?,?)");
		ins.setString(1, username);
		ins.setString(2, ph64);
		ins.setString(3, "none");
		if(ins.executeUpdate()!=1) return false;
		
		//Create an empty bio:
		PreparedStatement ibio=con.prepareStatement("insert into bios values(?,?)");
		ibio.setString(1, username);
		ibio.setString(2, "Nothing to see here yet.");
		//Insert values into bios table:
		if(ibio.executeUpdate()!=1) return false;
		
		//Return success:
		return true;
	}
	
	//Login to account, using login form and return session-id (sessionid) /user?action=login&username=USER&password=PASSWORD :
	private String login(String username, String password) throws Exception {
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		PreparedStatement st=con.prepareStatement("select username,passhash from users where username like ?");
		st.setString(1, username);
		ResultSet rs=st.executeQuery();
		
		String sessionid=new String("0");
		//Check if user exists:
		if(!rs.next()) return sessionid;
		
		//Check account:
		//Hash the password and encode it to Base64:
		MessageDigest sha256=MessageDigest.getInstance("SHA-256");
		byte[] passhash=sha256.digest(password.getBytes());
		String ph64=Base64.getEncoder().encodeToString(passhash);
		//Check if passwords match:
		if(rs.getString("passhash").equals(ph64)) {
			//Generate sessionid:
			String sid=String.valueOf(System.currentTimeMillis());
			sid=sid.concat(username);
			byte[] dig=sha256.digest(sid.getBytes());
			//Set sessionid:
			sessionid=Base64.getEncoder().encodeToString(dig);
			//Commit sessionid to database:
			PreparedStatement sd=con.prepareStatement("update users set sessionid = ? where username like ?");
			sd.setString(1, sessionid);
			sd.setString(2, username);
			if(sd.executeUpdate()!=1) throw new Exception("hmm");
		}
		return sessionid;
	}
	
	//Logout /user?action=logout :
	private boolean logout(String sessionid) throws Exception {
		//Check if sessionid exists in DB:
		//Connect to SQL server:
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1/knet", "knet", "knet123");
		//Check sessionid in database:
		PreparedStatement chk=con.prepareStatement("select sessionid from users where sessionid like ?");
		chk.setString(1, sessionid);
		ResultSet rs=chk.executeQuery();
		if(!rs.next()) return false;
		//Delete sessionid:
		PreparedStatement upd=con.prepareStatement("update users set sessionid=\'none\' where sessionid like ?");
		upd.setString(1, sessionid);
		if(upd.executeUpdate()!=1) return false;
		return true;
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		BufferedWriter out=new BufferedWriter(res.getWriter());
		//Process request:
		String action=req.getParameter("action");
		//Create new account:
		if(action.equals("register")) {
			boolean success=false;
			try {
				String pw=req.getParameter("password");
				if(!req.getParameter("pconfirm").equals(pw)) throw new Exception("Password mismatch!");
				success=createAccount(req.getParameter("username"), req.getParameter("password"));
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error creating account: " + e.getMessage() + "</font></body></html>");
				out.flush();
				return;
			}
			if(success) try {
				//Login automatically:
				String sessionid=login(req.getParameter("username"), req.getParameter("password"));
				if(sessionid!=null) {
					Cookie co=new Cookie("session-id", sessionid);
					co.setMaxAge(3600);
					res.addCookie(co);
					res.sendRedirect("forum?threadid=0");
				}
				else {
					out.write("<html><body><font face=\"sans\">An unknown error occured. Sorry!</font></body></html>");
					out.flush();
				} 
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error logging in: " + e.getMessage() + "</font></body></html>");
				out.flush();
				return;
			}
			else {
				out.write("<html><body><font face=\"sans\">An unknown error occured. Sorry!</font></body></html>");
				out.flush();
			}
			out.close();
			return;
		}
		//Login:
		else if(action.equals("login")) {
			String sessionid=null;
			try {
				sessionid=login(req.getParameter("username"), req.getParameter("password"));
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error logging in: " + e.getMessage() + "</font></body></html>");
				return;
			}
			if(sessionid!=null) {
				Cookie co=new Cookie("session-id", sessionid);
				co.setMaxAge(3600);
				res.addCookie(co);
				res.sendRedirect("forum?threadid=0");
			}
			else {
				out.write("<html><body><font face=\"sans\">An unknown error occured. Sorry!</font></body></html>");
				out.flush();
			}
			out.close();
			return;
		}
		//Logout:
		else if(action.equals("logout")) {
			//Get cookies:
			Cookie[] c=req.getCookies();
			String sessionid=null;
			if(c!=null) for(Cookie c1: c) if(c1.getName().equals("session-id")) sessionid=c1.getValue();
			boolean success=false;
			try {
				if(sessionid==null) throw new Exception("Session cookie could not be retrieved.");
				success=logout(sessionid);
			} catch(Exception e) {
				out.write("<html><body><font face=\"sans\">Error logging out: " + e.getMessage() + "</font></body></html>");
				out.flush();
				return;
			}
			if(success)
				res.sendRedirect("forum?threadid=0");
			else {
				out.write("<html><body><font face=\"sans\">An unknown error occured. Sorry!</font></body></html>");
				out.flush();
			}
			out.close();
			return;
		}
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doPost(req, res);
	}
}
